import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double celsius;
        boolean validInput = false;
        
        // Prompt user to enter the temperature in Celsius until valid input is received
        do {
            System.out.print("Enter the temperature in Celsius: ");
            if (in.hasNextDouble()) {
                celsius = in.nextDouble();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid temperature.");
                in.nextLine(); // Clear the buffer
            }
        } while (!validInput);
        
        // Convert Celsius to Fahrenheit
        double fahrenheit = (celsius * 9/5) + 32;
        
        // Display the equivalent temperature in Fahrenheit
        System.out.println("Equivalent temperature in Fahrenheit: " + fahrenheit);
        
        in.close();
    }
}
