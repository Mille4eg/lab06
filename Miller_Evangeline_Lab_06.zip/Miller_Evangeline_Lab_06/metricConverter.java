import java.util.Scanner;

public class MeasurementConverter {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        // Variables to store user input and converted measurements
        double meters;
        double miles;
        double feet;
        double inches;
        boolean validInput = false;
        
        // Prompt user to input measurement in meters until valid input is received
        do {
            System.out.print("Enter the measurement in meters: ");
            if (in.hasNextDouble()) {
                meters = in.nextDouble();
                validInput = true;
                
                // Convert meters to miles, feet, and inches
                miles = meters * 0.000621371;
                feet = meters * 3.28084;
                inches = meters * 39.3701;
                
                // Print the converted measurements
                System.out.println("Measurement in miles: " + miles);
                System.out.println("Measurement in feet: " + feet);
                System.out.println("Measurement in inches: " + inches);
            } else {
                System.out.println("Invalid input. Please enter a valid measurement.");
                in.nextLine(); // Clear the buffer
            }
        } while (!validInput);
        
        in.close();
    }
}
