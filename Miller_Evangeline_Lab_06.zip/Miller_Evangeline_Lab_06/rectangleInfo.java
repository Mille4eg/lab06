import java.util.Scanner;

public class RectangleCalculator {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        // Variables to store user inputs
        double width = 0;
        double height = 0;
        boolean validInput = false;
        
        // Prompt user to input width until valid input is received
        do {
            System.out.print("Enter the width of the rectangle: ");
            if (in.hasNextDouble()) {
                width = in.nextDouble();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid width.");
                in.nextLine(); // Clear the buffer
            }
        } while (!validInput);
        
        validInput = false; 
        // Reset validInput for next input
        // do you ever start doing something and forget where you are 
        
        // Prompt user to input height until valid input is received
        do {
            System.out.print("Enter the height of the rectangle: ");
            if (in.hasNextDouble()) {
                height = in.nextDouble();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid height.");
                in.nextLine(); // Clear the buffer
            }
        } while (!validInput);
        
        // Calculate area
        double area = width * height;
        
        // Calculate perimeter
        double perimeter = 2 * (width + height);
        
        // Calculate length of the diagonal using Pythagorean theorem
        double diagonal = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
        
        // Print the results
        System.out.println("Area of the rectangle: " + area);
        System.out.println("Perimeter of the rectangle: " + perimeter);
        System.out.println("Length of the diagonal: " + diagonal);
        
        in.close();
    }
}
